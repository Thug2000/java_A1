public class Main {
    public static void main(String[] args) {
        Chess chess = new Chess();
        chess.play();
    }
}